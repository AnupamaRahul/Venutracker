﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Convention_Center_Registration : System.Web.UI.Page
{
    Connect con=new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
   }
 
protected void Button1_Click1(object sender, EventArgs e)
{
    string cid = "";
     string ext = "", ext1 = "", src = "", src1 = "";
        string filename="";
        try
        {
            con.dr = con.read("select count(*) from conventioncenterregistration");
            int count = 0;
            if(con.dr.Read())
            {
                count = Convert.ToInt16(con.dr.GetValue(0).ToString());
            }
            con.dr.Close();
            count++;
            cid = "con" + count;












            filename=txtimage.PostedFile.FileName;
            if (txtimage.PostedFile.FileName.Length != 0)
            {
                ext = filename.Substring(filename.Length - 3);
                ext = ext.ToUpper();
                ext1 = filename.Substring(filename.Length - 4);
                ext1 = ext1.ToUpper();
                if (ext == "JPG")
                {
                    src = Server.MapPath("images") + "/" + cid + ".JPG";
                    txtimage.PostedFile.SaveAs(src);
                    src1 = "-/images/" + cid + ".JPG";
                }
                else if (ext1 == "JPEG")
                {
                    src = Server.MapPath("images") +cid+ ".JPEG";
                    txtimage.PostedFile.SaveAs(src);
                    src1 = "-/images/" + cid + ".JPEG";
                }
            
            else
            {
            }
        }}
catch(Exception ee)
        {
    Response.Write(ee.ToString());
}
    try
    {
        con.dml("insert into conventioncenterregistration values('" + cid + "','" + txtname.Text + "','" + txtloc.Text + "','" + txtrentperday.Text + "','" + txtcapacity.Text + "','" + txtroom.Text + "','" + src1 + "')");
        lblMsg.Text = "Registered!!!!";
    }
    catch(Exception ee)
    {
        Response.Write(ee.ToString());
        
    }



                
}}     