﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class catering_registration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            con.dr = con.read("select count(*) from cateringregistration");
            int count = 0;
            if (con.dr.Read())
            {
                count = Convert.ToInt16(con.dr.GetValue(0).ToString());
            }
            con.dr.Close();
            count++;
            string cid = "con" + count;
            con.dml("insert into users values('" +cid+ "','" +cid+ "','cateringservice')");
            con.dml("insert into cateringregistration(cateringserviceid,name,typeoffood)values('" + cid + "','" + txtname.Text + "','" + rdobtnfood.Text + "')");
            lblmsg.Text = "successfully registred!!!";
        }
        catch (Exception ee)
        {
            lblmsg.Text = "username already exists";
            Response.Write(ee.ToString());
        }
    }
}