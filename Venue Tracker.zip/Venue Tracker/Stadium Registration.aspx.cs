﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Stadium_Registration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string ext = "", ext1 = "", src = "", src1 = "";
        string filename="";
        try
        {
            filename = txtimage.PostedFile.FileName;
            if (txtimage.PostedFile.FileName.Length != 0)
            {
                ext = filename.Substring(filename.Length - 3);
                ext = ext.ToUpper();
                ext1 = filename.Substring(filename.Length - 4);
                ext1 = ext1.ToUpper();
                if (ext == "JPG")
                {
                    src = Server.MapPath("images") + "/" + txtid.Text + ".JPEG";
                    txtimage.PostedFile.SaveAs(src);
                    src1 = "-/images/" + txtid.Text + ".JPG";
                }
                else if (ext1 == "JPEG")
                {
                    src = Server.MapPath("images") + txtid.Text + ".JPEG";
                    txtimage.PostedFile.SaveAs(src);
                    src1 = "-/images/" + txtid .Text+ ".JPEG";
                }

                else
                {
                }
            }
        }
        catch (Exception ee)
        {
            Response.Write(ee.ToString());
        }


       
       con.dml("insert into stadiumregistration(id,name,capacity,bigscreenvideodisplay,changeroom,contactno,email,location,image)values('" + txtid.Text + "','" + txtname.Text + "','" + txtcapacity.Text + "','" + RadioButtonList1.SelectedItem.Text + "','" + RadioButtonList2.SelectedItem.Text + "','" + txtcontactno.Text + "','" + txtemail.Text + "','" +txtlocation.Text+"','"+src1+"')");
        lblmsg.Text = "successfully Registered!!!";

    }
}