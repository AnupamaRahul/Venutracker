﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class complaint_registration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();

    }
    protected void send_Click(object sender, EventArgs e)
    {
        try
        {
            con.dr = con.read("select count(*)from complaints");
            int count = 0;
            if (con.dr.Read())
            {
                count = Convert.ToInt32(con.dr.GetValue(0).ToString());
            }
            con.dr.Close();
            count++;
            string ComplaintID = "COMOO" + count;
            con.dml("insert into complaints(complaintid,username,subject,submitdate,complaindetails)values('" + ComplaintID + "','" + Session["username"].ToString() + "','" + txtsub.Text + "','" + DateTime.Now.ToString() + "','" + txtcomplaindetails.Text + "')");
            lblmsg.Text = "saved";
        }
        catch(Exception ee)
        {
            lblmsg.Text = "Not Saved";
            Response.Write(ee.ToString());
        }

    }
}