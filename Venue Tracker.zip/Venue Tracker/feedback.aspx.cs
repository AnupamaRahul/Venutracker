﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class feedback : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            con.dr = con.read("select count(*)from feedback");
            int count = 0;
            if (con.dr.Read())
            {
                count = Convert.ToInt32(con.dr.GetValue(0).ToString());
            }
            con.dr.Close();
            count++;
            string cusid = "fed00" + count;
            con.dml("insert into feedback(feedbackid,name,address,contactno,feedbacks,submitdate)values('"+cusid+"','" + txtname.Text + "','" + TxtAdd.Text + "','" + Txtno.Text + "','" + txtfeed.Text + "','" + DateTime.Now.ToShortDateString() + "')");
            lblM.Text = "registered";
        }
        catch (Exception ee)
     
       {

            lblM.Text = "feedback not send";
            Response.Write(ee.ToString());
        }


    }
}
