﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page
{
    Connect con=new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
       con.start();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string usertype="";
        con.dr=con.read("select * from users where username='"+ txtname.Text+"'and password='"+txtpwd.Text+"'");
        if (con.dr.Read())
        {
            Session["username"] = txtname.Text;
            usertype = con.dr.GetValue(2).ToString();
            Session["utype"] = usertype;
            if (usertype.Equals("Admin"))
            {
                Response.Redirect("Adminarea.aspx");
            }
            else if (usertype.Equals("Public"))
            {
                Response.Redirect("publicarea.aspx");

            }
            else if (usertype.Equals("program coordinator"))
            {
                Response.Redirect("programcoordinatorarea.aspx");
            }

            else if (usertype.Equals("cateringservice"))
            {
                Response.Redirect("cateringservicearea.aspx");
            }
            



            


        }
        else
        {
            lblmsg.Text = "Invalid password";
        }
con.dr.Close();
}

}