﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewAndReplyComplaint : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
        fillgrid();

    }
    public void fillgrid()
    {
        DataGrid1.DataSource = con.fill("select * from complaints where replydate is null").Tables[0].DefaultView;
        DataGrid1.DataBind();
    }
    protected void btn1_Click(object sender, EventArgs e)
    {


    }
    protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
    {
     
        

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
       

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.dml("update complaints set replydate='" + DateTime.Now.ToShortDateString() + "',reply='" + TextBox1.Text + "' where complaintid='" + DataGrid1.SelectedItem.Cells[0].Text + "'");
        lblmsg.Text = "complaint reply successfully send";
    }
    protected void DataGrid1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        txtcomplaint.Visible = true;
        txtcomplaint.Text = DataGrid1.SelectedItem.Cells[3].Text;
    }
}