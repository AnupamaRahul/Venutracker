﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class view_and_booking_request : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
        fillgrid();
    }
    public void fillgrid()
    {
        DataGrid1.DataSource=con.fill("select * from Bookingdetails where Status='request'").Tables[0].DefaultView;
        DataGrid1.DataBind();
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        con.dml("update Bookingdetails set status='"+DropDownList1.SelectedItem.ToString()+"' where BookingNumber='" + DataGrid1.SelectedItem.Cells[0].Text + "'");
        Label2.Text = "Status Updated Successfully";
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
    