﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Foodand_BeverageRegistration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
    }
    protected void Button1_Click2(object sender, EventArgs e)
    {
        con.dml("insert into foodandbeverageregistration values('"+txtid.Text+"','"+txtname.Text+"','"+txtloc.Text+"','"+txtfood.Text+"','"+txtminimum.Text+"')");
        lblmsg.Text = "Seccessfully Registered";
    }
}