﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Auditoriumbooking : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
       
        con.start();
        fillgrid();
        
    }
    protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Panel1.Visible = true;
    }
    public void fillgrid()
    {
        DataGrid1.DataSource = con.fill("select * from auditoriumregistration").Tables[0].DefaultView;
        DataGrid1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.dr = con.read("select count(*)from Bookingdetails");
        int count = 0;
        if (con.dr.Read())
        {
            count = Convert.ToInt32(con.dr.GetValue(0).ToString());
        }
        con.dr.Close();
        count++;
        string bookingid = "Book" + count;

        con.dml("insert into Bookingdetails values('" + bookingid + "','" + Session["username"].ToString() + "','Request','" + DateTime.Now.ToShortDateString() + "','" + txtnum.Text + "','Auditorium','"+DataGrid1.SelectedItem.Cells[0].Text+"')");
        lblmsg.Text = "Successfull";
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {

    }
}