﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Theater_Registration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.dml("insert into Theaterregistration values('" + txtid.Text + "','" + txtname.Text + "','" + txtseatcapacity.Text + "','" +txtstagedia.Text + "','" + txtlightpos.Text + "','" + txtsound.Text + "')");
        lblmsg.Text = "successfully Registered!!!";
    }
}