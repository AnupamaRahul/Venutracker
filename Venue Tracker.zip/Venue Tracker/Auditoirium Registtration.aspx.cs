﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Auditoirium_Registtration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
           
            con.dml("insert into auditoriumregistration(id,name,seatingcapacity,stagediamension,lightingposition,sound)values('" + txtid.Text + "','" + txtname.Text + "','" + txtseating.Text + "','" + txtstage.Text + "','" + txtlighting.Text + "','" + txtsound.Text + "')");
            lblmsg.Text = "successfully Registered!!!";
        }
        catch
        {
            lblmsg.Text = "ID Already Exist!!!";
        }

    }
}