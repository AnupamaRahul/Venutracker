﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ChangePassword : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            con.dr = con.read("select * from users where username='" + Session["username"].ToString() + "'and password='" +TxtOldPwd.Text+ "'");
            if (con.dr.Read())
            {
                con.dr.Close();
                con.dml("update users set password='" + TxtPwd.Text +"'where username='" + Session["username"].ToString() + "'");
                lblmsg.Text = " password updated";
            }
            else
            {
                con.dr.Close();
                lblmsg.Text = "invalid current password";
            }
        }
        catch (Exception ee)
        {
            lblmsg.Text = "failed!!!";
            Response.Write(ee.ToString());
        }
    }
}

             
   