﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Back : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string usertype = Session["utype"].ToString();
        if (usertype.Equals("ADMIN"))
        {
            Response.Redirect("Adminarea.aspx");
        }
        else if (usertype.Equals("Public"))
        {
            Response.Redirect("publicarea.aspx");
        }
        else if (usertype.Equals("programcoordinator"))
        {
            Response.Redirect("programcoordinatorarea.aspx");
        }
    }
}