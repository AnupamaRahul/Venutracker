﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class stadium_booking_registration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
        fillgrid();
    }
    public void fillgrid()
    {
        DataGrid1.DataSource = con.fill("select * from stadiumregistration").Tables[0].DefaultView;
        DataGrid1.DataBind();
    }
    protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Panel1.Visible = true;
      
    }
    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        con.dr = con.read("select count(*)from Bookingdetails");
        int count = 0;
        if (con.dr.Read())
        {
            count = Convert.ToInt32(con.dr.GetValue(0).ToString());
        }
        con.dr.Close();
        count++;
        string bookingid = "Book" + count;

        con.dml("insert into Bookingdetails values('" + bookingid + "','" + Session["username"].ToString() + "','Request','" + txtrdate.Text + "','" + txtcno.Text + "','stadium','" + DataGrid1.SelectedItem.Cells[0].Text + "')");
        Label4.Text = "Booking Request Send Your Booking Id Is " + bookingid;
    }
}