﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PublicRegistreation : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            con.dml("insert into users values('" + Txtusername.Text + "','" + TxtPwd.Text + "','Public')");
            lbl1.Text = "Sucessfully registered";
            con.dml("insert into publicregistration(username,fullname,address,gender,email,phonenumber,accountnumber)values('" + Txtusername.Text + "','" + TxtFullname.Text + "','" + Txtadd.Text + "','" + RadioButtonList1.SelectedItem.Text + "','" + TxtEmailid.Text + "','" + TxtPhoneno.Text + "','" + TxtAcntno.Text + "')");
            lblmsg.Text = "successfully Registered";
        }
        catch (Exception ee)
        {
            lblmsg.Text = "username already exist";
            Response.Write(ee.ToString());

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.dr = con.read("select * from Users where UserName='" + Txtusername.Text + "'");
        if (con.dr.Read())
        {
            lblMsg1.Text = "Not Available......";
        }
        else
        {
            lblMsg1.Text = "Available.........";
        }
    }
}