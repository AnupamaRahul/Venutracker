﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewFeedback : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void page_Load(object sender,EventArgs e)
    {
        con.start();
        fillgrid();
    }
    public void fillgrid()
    {
        d1.DataSource = con.fill("select * from feedback").Tables[0].DefaultView;
        d1.DataBind();
    }
   
   
    protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
    {
       string msgid=d1.SelectedItem.Cells[0].Text;
       con.dml("delete from feedback where feedbackid='"+msgid+"'");
       lblmsg.Text="";
       fillgrid();
    }
}