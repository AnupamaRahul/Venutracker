﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Program_Coordinator_Restration : System.Web.UI.Page
{
    Connect con = new Connect();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.start();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
try
{
    con.dml("insert into users(username,password,usertype)values('"+txtID.Text+"','"+txtpwd.Text+"','program coordinator')");
    con.dml("insert into programcoordinatorregistertion(username,name,address,DOB,ContactNumber,Qualification,Experience,gender)values('" + txtID.Text + "','" + txtName.Text + "','" + txtadd.Text + "','" + txtDOB.Text + "','" + txtcno.Text + "','" + txtgender.Text + "','" + txtqualification.Text + "','" + txtexp.Text + "')");
    lblmsg.Text = "successfully Registered!!";
}
        catch(Exception ee)
{
            lblmsg.Text="username already exists";
            Response.Write(ee.ToString());
        }
}
    }
